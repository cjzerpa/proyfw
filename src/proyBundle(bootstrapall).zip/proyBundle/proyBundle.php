<?php

namespace proyBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class proyBundle extends Bundle
{
}
